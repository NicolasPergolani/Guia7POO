package extra.ejercicio.pkg06;

import Servicio.AhorcadoServicio;

public class ExtraEjercicio06 {

    public static void main(String[] args) {
        
        AhorcadoServicio as = new AhorcadoServicio();
        
       as.juego();
    }

}
